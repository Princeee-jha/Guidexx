import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { WebSocketServer, WebSocket } from "ws";
import { insertExpertQuerySchema, insertMessageSchema } from "@shared/schema";
import { z } from "zod";
import { randomUUID } from "crypto";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Setup WebSocket server for real-time chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Handle WebSocket connections
  wss.on('connection', (ws: WebSocket) => {
    // Send initial message when client connects
    ws.send(JSON.stringify({
      type: 'connection',
      message: 'Connected to Guidex chat server'
    }));
    
    // Handle messages from clients
    ws.on('message', async (message: string) => {
      try {
        const data = JSON.parse(message);
        
        if (data.type === 'chat') {
          // Save the message to storage
          const newMessage = await storage.createMessage({
            content: data.message,
            sender: data.sender
          });
          
          // Broadcast message to all connected clients
          wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: 'chat',
                id: newMessage.id,
                message: newMessage.content,
                sender: newMessage.sender,
                timestamp: newMessage.createdAt
              }));
            }
          });
        }
      } catch (error) {
        console.error('Error handling WebSocket message:', error);
        ws.send(JSON.stringify({
          type: 'error',
          message: 'Failed to process message'
        }));
      }
    });
  });
  
  // API endpoints
  
  // Get all experts
  app.get('/api/experts', async (req: Request, res: Response) => {
    try {
      const experts = await storage.getExperts();
      res.json(experts);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch experts' });
    }
  });
  
  // Get expert by id
  app.get('/api/experts/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const expert = await storage.getExpert(id);
      
      if (!expert) {
        return res.status(404).json({ message: 'Expert not found' });
      }
      
      res.json(expert);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch expert' });
    }
  });
  
  // Submit expert query
  app.post('/api/expert-queries', async (req: Request, res: Response) => {
    try {
      const queryData = insertExpertQuerySchema.parse(req.body);
      const query = await storage.createExpertQuery(queryData);
      res.status(201).json(query);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid query data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to submit query' });
    }
  });
  
  // Get chat messages
  app.get('/api/messages', async (req: Request, res: Response) => {
    try {
      const messages = await storage.getMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch messages' });
    }
  });
  
  // AI Assistant endpoints
  
  // Get AI chat history for a user
  app.get('/api/ai-chat/:userId', async (req: Request, res: Response) => {
    try {
      const userId = req.params.userId;
      const messages = await storage.getAiMessages(userId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch AI chat history' });
    }
  });
  
  // Send message to AI assistant
  app.post('/api/ai-chat/:userId', async (req: Request, res: Response) => {
    try {
      const userId = req.params.userId;
      const { message } = req.body;
      
      if (!message || typeof message !== 'string') {
        return res.status(400).json({ message: 'Message is required' });
      }
      
      // Save user message
      await storage.saveAiMessage(userId, { role: 'user', content: message });
      
      // Get the current conversation history
      const messages = await storage.getAiMessages(userId);
      
      // Import the OpenAI service dynamically to avoid circular dependencies
      const { generateAIResponse } = await import('./services/openai');
      
      try {
        // Generate AI response with proper error handling
        const aiResponse = await generateAIResponse(messages);
        
        // Save AI response
        await storage.saveAiMessage(userId, { role: 'assistant', content: aiResponse });
        
        // Return updated messages
        const updatedMessages = await storage.getAiMessages(userId);
        res.json(updatedMessages);
      } catch (aiError: any) {
        console.error('Error generating AI response:', aiError);
        
        // Create appropriate error message based on the error
        let errorMessage = "I'm sorry, I'm having trouble connecting to my knowledge base right now. Please try again in a moment.";
        
        // Provide more specific error messages
        if (aiError.message && aiError.message.includes("API key")) {
          errorMessage = "I'm sorry, there seems to be an issue with the API key configuration. Please contact support to resolve this issue.";
        } else if (aiError.message && aiError.message.includes("Too many requests")) {
          errorMessage = "I'm sorry, we're currently experiencing high demand. Please try again in a few minutes.";
        } else if (aiError.message && aiError.message.includes("experiencing issues")) {
          errorMessage = "I'm sorry, the AI service is temporarily unavailable. Please try again later.";
        }
        
        // Save the error message as the AI response
        await storage.saveAiMessage(userId, { role: 'assistant', content: errorMessage });
        
        // Return updated messages with the error
        const updatedMessages = await storage.getAiMessages(userId);
        res.json(updatedMessages);
      }
    } catch (error: any) {
      console.error('Error in AI chat endpoint:', error);
      res.status(500).json({ 
        error: true,
        message: 'Failed to process AI chat message',
        details: error.message || 'Unknown error occurred'
      });
    }
  });

  return httpServer;
}
