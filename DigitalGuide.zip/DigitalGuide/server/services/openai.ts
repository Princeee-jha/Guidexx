import OpenAI from "openai";
import type { ChatCompletionMessageParam, ChatCompletionUserMessageParam, ChatCompletionAssistantMessageParam, ChatCompletionSystemMessageParam } from "openai/resources";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const MODEL = "gpt-4o";

// Helper function to validate API key
function validateApiKey(apiKey: string | undefined): boolean {
  if (!apiKey) return false;
  return apiKey.startsWith('sk-') && apiKey.length > 20;
}

// Flag to determine if we should use fallback responses
const USE_FALLBACK = true; // Set to true for demo purposes when API key is invalid

/**
 * Generates a simulated AI response without using the OpenAI API
 * This is used as a fallback when API key is invalid or unavailable
 */
function generateFallbackResponse(messages: { role: string; content: string }[]): string {
  // Find the last user message
  const lastUserMessage = [...messages].reverse().find(msg => msg.role === 'user');
  if (!lastUserMessage) return "I'm here to help. What would you like to know?";
  
  const query = lastUserMessage.content.toLowerCase();
  
  // Predefined responses for common questions
  if (query.includes('hello') || query.includes('hi') || query.includes('hey')) {
    return "Hello! I'm the Guidex Assistant. How can I help you today?";
  }
  
  if (query.includes('how are you')) {
    return "I'm functioning well, thank you for asking! How can I assist you with Guidex today?";
  }
  
  if (query.includes('who are you') || query.includes('what are you')) {
    return "I'm the Guidex Assistant, designed to provide helpful information and guidance on various topics. I can answer questions, offer resources, and help you navigate through Guidex's features.";
  }
  
  if (query.includes('what can you do') || query.includes('help me')) {
    return "I can assist you with a variety of tasks related to Guidex. I can answer questions about technology, education, business strategies, and more. I can also provide guidance on how to use Guidex's features, connect with experts, or engage with the community. What specific area would you like help with?";
  }

  if (query.includes('coding') || query.includes('programming') || query.includes('developer')) {
    return "Programming is a valuable skill in today's digital world. To improve your coding skills, I recommend starting with online resources like freeCodeCamp, Codecademy, or MDN Web Docs. Practice regularly with small projects, join coding communities like Stack Overflow or GitHub, and consider contributing to open-source projects. Remember that consistent practice and building real projects are key to becoming a proficient programmer.";
  }
  
  if (query.includes('resources') || query.includes('learning') || query.includes('study')) {
    return "There are many excellent resources for beginners! I recommend:\n\n1. Online platforms like Coursera, edX, and Khan Academy offer free or affordable courses on various subjects.\n\n2. For programming, try freeCodeCamp, Codecademy, or The Odin Project.\n\n3. YouTube channels like Crash Course or MIT OpenCourseWare provide educational content.\n\n4. Join communities related to your interests on Reddit or Discord to connect with like-minded learners and experts.";
  }
  
  if (query.includes('interview') || query.includes('job') || query.includes('career')) {
    return "To prepare for technical interviews, focus on these key areas:\n\n1. Study fundamental concepts in your field and practice explaining them clearly.\n\n2. Solve practice problems regularly using platforms like LeetCode, HackerRank, or CodeSignal.\n\n3. Practice whiteboarding and talking through your problem-solving process.\n\n4. Research the company thoroughly and prepare questions to ask your interviewers.\n\n5. Conduct mock interviews with peers or use services like Pramp for feedback.";
  }
  
  if (query.includes('career') || query.includes('path') || query.includes('profession')) {
    return "There are numerous career paths available in tech! Some popular options include:\n\n1. Software Development/Engineering - Building applications and systems\n\n2. Data Science/Analysis - Working with large datasets to extract insights\n\n3. UX/UI Design - Creating user-friendly interfaces and experiences\n\n4. DevOps/SRE - Managing infrastructure and deployment processes\n\n5. Product Management - Overseeing product development and strategy\n\n6. Cybersecurity - Protecting systems and data from threats\n\nConsider your interests, strengths, and work preferences when choosing a path. Many roles also allow for specialization as you gain experience.";
  }
  
  // Default response for other queries
  return "That's an interesting question. To give you the most helpful information, I'd need to understand more about what you're looking for. Could you provide more details or context about your question? I'm here to help with resources, expert advice, or community support related to your specific needs.";
}

// Initialize OpenAI client - do this lazily to catch runtime updates to environment variables
function getOpenAIClient() {
  const apiKey = process.env.OPENAI_API_KEY;
  
  if (!validateApiKey(apiKey)) {
    console.error("OPENAI_API_KEY is not set correctly in environment variables");
    throw new Error("Invalid or missing OpenAI API key.");
  }
  
  return new OpenAI({
    apiKey: apiKey,
  });
}

/**
 * Generates a response from the AI using the provided conversation history
 * @param messages Array of messages in the conversation
 * @returns The AI response
 */
export async function generateAIResponse(messages: { role: string; content: string }[]): Promise<string> {
  try {
    // If using fallback, return simulated response immediately
    if (USE_FALLBACK) {
      console.log("Using fallback AI response generator instead of OpenAI API");
      return generateFallbackResponse(messages);
    }
    
    // Validate API key
    const apiKey = process.env.OPENAI_API_KEY;
    if (!validateApiKey(apiKey)) {
      throw new Error("Missing or invalid OpenAI API key. Please check your environment variables.");
    }
    
    // Create the OpenAI client
    const openai = getOpenAIClient();
    
    // Create a properly typed copy of messages
    const typedMessages: ChatCompletionMessageParam[] = [];
    
    // Convert each message to the correct type based on role
    for (const msg of messages) {
      if (msg.role === "user") {
        typedMessages.push({
          role: "user",
          content: msg.content
        } as ChatCompletionUserMessageParam);
      } else if (msg.role === "assistant") {
        typedMessages.push({
          role: "assistant",
          content: msg.content
        } as ChatCompletionAssistantMessageParam);
      } else if (msg.role === "system") {
        typedMessages.push({
          role: "system",
          content: msg.content
        } as ChatCompletionSystemMessageParam);
      }
    }
    
    // Add system message if not present
    if (!typedMessages.some(msg => msg.role === "system")) {
      typedMessages.unshift({
        role: "system",
        content: "You are the Guidex Assistant, a helpful guide that provides accurate and concise information to users' questions. Focus on providing practical advice and resources. Your responses should be informative but brief, around 2-3 paragraphs maximum."
      } as ChatCompletionSystemMessageParam);
    }

    // Log that we're calling the API (for debugging)
    console.log(`Calling OpenAI API with model ${MODEL} and ${typedMessages.length} messages`);

    // Call OpenAI API
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: typedMessages,
      temperature: 0.7,
      max_tokens: 800, // Reasonable limit for responses
    });

    // Return the AI response content
    return response.choices[0].message.content || "I'm sorry, I couldn't generate a response.";
  } catch (error: any) {
    console.error("Error generating AI response:", error);
    
    // If API is failing, use fallback
    console.log("OpenAI API error occurred, using fallback response generator");
    return generateFallbackResponse(messages);
  }
}