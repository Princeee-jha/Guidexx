import { 
  users, 
  experts,
  expertQueries,
  messages,
  aiMessages,
  type User, 
  type InsertUser, 
  type Expert, 
  type InsertExpert,
  type ExpertQuery,
  type InsertExpertQuery,
  type Message,
  type InsertMessage,
  type AiMessage,
  type InsertAiMessage
} from "@shared/schema";
import { eq } from "drizzle-orm";
import fs from "fs";
import path from "path";
import { randomUUID } from "crypto";

// Define the interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Expert operations
  getExperts(): Promise<Expert[]>;
  getExpert(id: number): Promise<Expert | undefined>;
  createExpert(expert: InsertExpert): Promise<Expert>;
  
  // Expert query operations
  createExpertQuery(query: InsertExpertQuery): Promise<ExpertQuery>;
  getExpertQueries(): Promise<ExpertQuery[]>;
  
  // Chat message operations
  getMessages(): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // AI messages operations
  getAiMessages(userId: string): Promise<{role: string, content: string}[]>;
  saveAiMessage(userId: string, message: {role: string, content: string}): Promise<void>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private experts: Map<number, Expert>;
  private expertQueries: Map<number, ExpertQuery>;
  private messages: Map<number, Message>;
  private aiMessages: Map<string, {role: string, content: string}[]>;
  private userIdCounter: number;
  private expertIdCounter: number;
  private queryIdCounter: number;
  private messageIdCounter: number;
  private dataDir: string;

  constructor() {
    this.users = new Map();
    this.experts = new Map();
    this.expertQueries = new Map();
    this.messages = new Map();
    this.aiMessages = new Map();
    this.userIdCounter = 1;
    this.expertIdCounter = 1;
    this.queryIdCounter = 1;
    this.messageIdCounter = 1;
    
    // Create data directory for JSON storage
    this.dataDir = path.join(process.cwd(), 'data');
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
    }
    
    // Initialize with sample data
    this.initializeExperts();
  }
  
  private initializeExperts() {
    const experts: InsertExpert[] = [
      {
        name: "Dr. Priya Sharma",
        profession: "Technology Expert",
        description: "Specialized in software development, AI technologies, and digital transformation strategies.",
        specializations: ["AI", "Software", "Innovation"],
        avatarColor: "amber"
      },
      {
        name: "Rahul Mehta",
        profession: "Education Advisor",
        description: "Expert in educational technology, learning methodologies, and career development in tech.",
        specializations: ["Education", "Career", "Learning"],
        avatarColor: "indigo"
      },
      {
        name: "Anika Patel",
        profession: "Business Strategist",
        description: "Specializes in business growth, digital marketing, and entrepreneurship in the tech space.",
        specializations: ["Marketing", "Growth", "Startup"],
        avatarColor: "emerald" 
      },
      {
        name: "Michael Zhang",
        profession: "Creative Director",
        description: "Expert in UI/UX design, creative technology, and building effective digital products.",
        specializations: ["Design", "UX", "Product"],
        avatarColor: "purple"
      }
    ];
    
    experts.forEach(expert => {
      this.createExpert(expert);
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }
  
  // Expert operations
  async getExperts(): Promise<Expert[]> {
    return Array.from(this.experts.values());
  }
  
  async getExpert(id: number): Promise<Expert | undefined> {
    return this.experts.get(id);
  }
  
  async createExpert(insertExpert: InsertExpert): Promise<Expert> {
    const id = this.expertIdCounter++;
    const expert: Expert = { 
      ...insertExpert, 
      id,
      createdAt: new Date()
    };
    this.experts.set(id, expert);
    return expert;
  }
  
  // Expert query operations
  async createExpertQuery(insertQuery: InsertExpertQuery): Promise<ExpertQuery> {
    const id = this.queryIdCounter++;
    const createdAt = new Date();
    const query: ExpertQuery = { 
      ...insertQuery, 
      id, 
      expertId: null,
      userId: null,
      createdAt 
    };
    this.expertQueries.set(id, query);
    
    // Store in JSON file
    const filePath = path.join(this.dataDir, 'expert-queries.json');
    let queries: ExpertQuery[] = [];
    
    try {
      if (fs.existsSync(filePath)) {
        const data = fs.readFileSync(filePath, 'utf8');
        queries = JSON.parse(data);
      }
      
      queries.push(query);
      fs.writeFileSync(filePath, JSON.stringify(queries, null, 2));
    } catch (error) {
      console.error('Error saving expert query:', error);
    }
    
    return query;
  }
  
  async getExpertQueries(): Promise<ExpertQuery[]> {
    return Array.from(this.expertQueries.values());
  }
  
  // Chat message operations
  async getMessages(): Promise<Message[]> {
    return Array.from(this.messages.values());
  }
  
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageIdCounter++;
    const createdAt = new Date();
    const message: Message = { 
      ...insertMessage, 
      id, 
      createdAt, 
      userId: null 
    };
    this.messages.set(id, message);
    return message;
  }
  
  // AI messages operations
  async getAiMessages(userId: string): Promise<{role: string, content: string}[]> {
    if (!this.aiMessages.has(userId)) {
      // Initialize with a system message
      this.aiMessages.set(userId, [
        { 
          role: "system", 
          content: "You are the Guidex Assistant, a helpful guide that provides accurate and concise information to users' questions."
        },
        { 
          role: "assistant", 
          content: "Hello! I'm the Guidex Assistant. How can I help you today?"
        }
      ]);
    }
    
    return this.aiMessages.get(userId) || [];
  }
  
  async saveAiMessage(userId: string, message: {role: string, content: string}): Promise<void> {
    const messages = await this.getAiMessages(userId);
    messages.push(message);
    this.aiMessages.set(userId, messages);
  }
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  constructor() {
    // Initialize database by adding sample experts if needed
    this.initializeExperts();
  }
  
  private async initializeExperts() {
    // Check if we already have experts in the database
    const { db } = await import('./db');
    const { experts } = await import('@shared/schema');
    const existingExperts = await db.select().from(experts);
    
    // If no experts, add sample data
    if (existingExperts.length === 0) {
      const experts: InsertExpert[] = [
        {
          name: "Dr. Priya Sharma",
          profession: "Technology Expert",
          description: "Specialized in software development, AI technologies, and digital transformation strategies.",
          specializations: ["AI", "Software", "Innovation"],
          avatarColor: "amber"
        },
        {
          name: "Rahul Mehta",
          profession: "Education Advisor",
          description: "Expert in educational technology, learning methodologies, and career development in tech.",
          specializations: ["Education", "Career", "Learning"],
          avatarColor: "indigo"
        },
        {
          name: "Anika Patel",
          profession: "Business Strategist",
          description: "Specializes in business growth, digital marketing, and entrepreneurship in the tech space.",
          specializations: ["Marketing", "Growth", "Startup"],
          avatarColor: "emerald" 
        },
        {
          name: "Michael Zhang",
          profession: "Creative Director",
          description: "Expert in UI/UX design, creative technology, and building effective digital products.",
          specializations: ["Design", "UX", "Product"],
          avatarColor: "purple"
        }
      ];
      
      // Add experts to database
      for (const expert of experts) {
        await this.createExpert(expert);
      }
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const { db } = await import('./db');
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const { db } = await import('./db');
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const { db } = await import('./db');
    const [createdUser] = await db.insert(users).values({
      ...user,
      createdAt: new Date()
    }).returning();
    return createdUser;
  }
  
  // Expert operations
  async getExperts(): Promise<Expert[]> {
    const { db } = await import('./db');
    return await db.select().from(experts);
  }
  
  async getExpert(id: number): Promise<Expert | undefined> {
    const { db } = await import('./db');
    const [expert] = await db.select().from(experts).where(eq(experts.id, id));
    return expert;
  }
  
  async createExpert(expert: InsertExpert): Promise<Expert> {
    const { db } = await import('./db');
    const [createdExpert] = await db.insert(experts).values({
      ...expert,
      createdAt: new Date()
    }).returning();
    return createdExpert;
  }
  
  // Expert query operations
  async createExpertQuery(query: InsertExpertQuery): Promise<ExpertQuery> {
    const { db } = await import('./db');
    const [createdQuery] = await db.insert(expertQueries).values({
      ...query,
      expertId: null,
      userId: null,
      createdAt: new Date()
    }).returning();
    return createdQuery;
  }
  
  async getExpertQueries(): Promise<ExpertQuery[]> {
    const { db } = await import('./db');
    return await db.select().from(expertQueries);
  }
  
  // Chat message operations
  async getMessages(): Promise<Message[]> {
    const { db } = await import('./db');
    return await db.select().from(messages);
  }
  
  async createMessage(message: InsertMessage): Promise<Message> {
    const { db } = await import('./db');
    const [createdMessage] = await db.insert(messages).values({
      ...message,
      userId: null,
      createdAt: new Date()
    }).returning();
    return createdMessage;
  }
  
  // AI messages operations
  async getAiMessages(userId: string): Promise<{role: string, content: string}[]> {
    const { db } = await import('./db');
    
    // Check if user has any messages
    const userMessages = await db.select().from(aiMessages)
      .where(eq(aiMessages.userId, userId))
      .orderBy(aiMessages.createdAt);
    
    // If no messages, initialize with system and welcome message
    if (userMessages.length === 0) {
      await this.saveAiMessage(userId, { 
        role: "system", 
        content: "You are the Guidex Assistant, a helpful guide that provides accurate and concise information to users' questions."
      });
      
      await this.saveAiMessage(userId, { 
        role: "assistant", 
        content: "Hello! I'm the Guidex Assistant. How can I help you today?"
      });
      
      return this.getAiMessages(userId);
    }
    
    // Map to the expected format
    return userMessages.map(msg => ({
      role: msg.role,
      content: msg.content
    }));
  }
  
  async saveAiMessage(userId: string, message: {role: string, content: string}): Promise<void> {
    const { db } = await import('./db');
    const { aiMessages } = await import('@shared/schema');
    
    await db.insert(aiMessages).values({
      userId,
      role: message.role,
      content: message.content,
      createdAt: new Date()
    });
  }
}

// Export the database storage implementation
export const storage = new DatabaseStorage();
