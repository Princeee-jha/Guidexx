import { useState, useEffect } from 'react';
import { useLanguage } from "@/contexts/LanguageContext";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertExpertQuerySchema } from "@shared/schema";
import { Expert } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const formSchema = insertExpertQuerySchema.extend({
  terms: z.boolean().refine((val) => val === true, {
    message: "You must agree to the terms and conditions",
  }),
});

type FormData = z.infer<typeof formSchema>;

const ContactExperts = () => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch experts
  const { data: experts = [], isLoading: expertsLoading } = useQuery<Expert[]>({
    queryKey: ['/api/experts'],
  });

  // Form setup
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      topic: "",
      message: "",
      contactMethod: "email",
      terms: false,
    },
  });

  // Submit mutation
  const submitMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const { terms, ...queryData } = data;
      const response = await apiRequest('POST', '/api/expert-queries', queryData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: t('formSubmitted'),
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/expert-queries'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to submit your query. Please try again.",
        variant: "destructive",
      });
      console.error('Form submission error:', error);
    },
  });

  const onSubmit = (data: FormData) => {
    submitMutation.mutate(data);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{t('contactExperts')}</h1>
          <p className="text-gray-600">{t('contactExpertsLongDesc')}</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {expertsLoading ? (
            <div className="col-span-2 text-center py-8">Loading experts...</div>
          ) : (
            experts.map((expert) => (
              <Card key={expert.id} className="bg-white rounded-xl shadow-md hover:shadow-lg transition overflow-hidden border border-gray-100">
                <div className="p-6 flex space-x-4">
                  <div className={`w-20 h-20 rounded-full bg-${expert.avatarColor}-100 flex-shrink-0 flex items-center justify-center`}>
                    <svg xmlns="http://www.w3.org/2000/svg" className={`h-10 w-10 text-${expert.avatarColor}-500`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                    </svg>
                  </div>
                  <div className="flex-grow">
                    <h3 className="text-lg font-semibold text-gray-800 mb-1">{expert.name}</h3>
                    <p className={`text-${expert.avatarColor}-500 font-medium mb-2`}>{expert.profession}</p>
                    <p className="text-gray-600 text-sm mb-3">{expert.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {expert.specializations.map((specialization, index) => (
                        <span key={index} className="bg-gray-100 text-gray-700 text-xs rounded-full px-2 py-1">
                          {specialization}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
        
        {/* Contact Form */}
        <Card className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden mb-8">
          <div className="border-b border-gray-200 p-6">
            <h2 className="text-2xl font-bold text-gray-800">{t('contactForm')}</h2>
            <p className="text-gray-600 mt-1">{t('contactFormDesc')}</p>
          </div>
          
          <div className="p-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('fullName')}</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            className="w-full rounded-lg border border-gray-300 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('email')}</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="email"
                            className="w-full rounded-lg border border-gray-300 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="topic"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('selectTopic')}</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="w-full rounded-lg border border-gray-300 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent">
                            <SelectValue placeholder={t('chooseTopic')} />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="technology">Technology & AI</SelectItem>
                          <SelectItem value="education">Education & Learning</SelectItem>
                          <SelectItem value="business">Business & Marketing</SelectItem>
                          <SelectItem value="design">Design & Creativity</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('yourQuestion')}</FormLabel>
                      <FormControl>
                        <Textarea 
                          {...field} 
                          rows={4}
                          className="w-full rounded-lg border border-gray-300 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="contactMethod"
                  render={({ field }) => (
                    <FormItem className="space-y-3">
                      <FormLabel>{t('preferredContact')}</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex space-x-4"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="email" id="r1" />
                            <Label htmlFor="r1">{t('email')}</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="chat" id="r2" />
                            <Label htmlFor="r2">{t('chatOption')}</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="video" id="r3" />
                            <Label htmlFor="r3">{t('videoCall')}</Label>
                          </div>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="terms"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>
                          {t('termsAgree')}
                        </FormLabel>
                        <FormMessage />
                      </div>
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full bg-primary hover:bg-indigo-600 text-white font-medium py-3 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition"
                  disabled={submitMutation.isPending}
                >
                  {submitMutation.isPending ? 'Submitting...' : t('submitQuestion')}
                </Button>
              </form>
            </Form>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default ContactExperts;
