import { useState, useEffect, useRef } from 'react';
import { useLanguage } from "@/contexts/LanguageContext";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface Message {
  role: string;
  content: string;
  timestamp?: Date;
  isLoading?: boolean;
  isError?: boolean;
}

interface AiAssistantProps {
  userId: string;
}

const AiAssistant = ({ userId }: AiAssistantProps) => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatMessagesRef = useRef<HTMLDivElement>(null);

  const suggestedQuestions = [
    "How can I improve my coding skills?",
    "What are the best resources for beginners?",
    "How do I prepare for technical interviews?",
    "What career paths are available in tech?"
  ];

  useEffect(() => {
    // Fetch chat history
    fetchMessages();
  }, [userId]);

  useEffect(() => {
    // Scroll to bottom on new messages
    scrollToBottom();
  }, [messages]);

  const fetchMessages = async () => {
    try {
      setIsLoading(true);
      const res = await fetch(`/api/ai-chat/${userId}`);
      if (!res.ok) {
        throw new Error(`Failed to fetch messages: ${res.status}`);
      }
      const data = await res.json();
      
      // Filter out system messages for display
      const displayMessages = data.filter((msg: Message) => msg.role !== 'system');
      setMessages(displayMessages);
    } catch (error) {
      console.error('Error fetching messages:', error);
      toast({
        title: 'Error',
        description: 'Failed to load chat history',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    try {
      setIsLoading(true);
      
      // Save the current input before clearing it
      const currentInput = input;
      
      // Optimistically update UI
      const userMessage: Message = { role: 'user', content: currentInput, timestamp: new Date() };
      setMessages(prev => [...prev, userMessage]);
      
      // Clear input field immediately for better UX
      setInput('');
      
      // Add temporary "AI is thinking" message
      const tempMessage: Message = { 
        role: 'assistant', 
        content: '...', 
        timestamp: new Date(),
        isLoading: true // Custom property to indicate loading state
      };
      setMessages(prev => [...prev, tempMessage]);
      
      // Scroll to the bottom to show the loading indicator
      setTimeout(() => scrollToBottom(), 100);
      
      // Send message to API
      const res = await apiRequest('POST', `/api/ai-chat/${userId}`, { message: currentInput });
      
      if (!res.ok) {
        throw new Error(`Server responded with status: ${res.status}`);
      }
      
      const data = await res.json();
      
      // Update with real messages from API (filtering system messages)
      const displayMessages = data.filter((msg: Message) => msg.role !== 'system');
      setMessages(displayMessages);
    } catch (error) {
      console.error('Error sending message:', error);
      
      // Remove temporary loading message
      setMessages(prev => prev.filter(msg => !msg.isLoading));
      
      // Add error message from AI
      const errorMessage: Message = { 
        role: 'assistant', 
        content: "I'm sorry, I encountered an error processing your request. Our team has been notified. Please try again in a moment.", 
        timestamp: new Date(),
        isError: true // Mark as error message
      };
      setMessages(prev => [...prev, errorMessage]);
      
      toast({
        title: 'Connection Error',
        description: 'Unable to connect to AI service. Please try again later.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
      
      // Ensure we scroll to the bottom after the update
      setTimeout(() => scrollToBottom(), 100);
    }
  };

  const handleSuggestedQuestion = (question: string) => {
    setInput(question);
  };

  const formatTime = (date?: Date) => {
    if (!date) return '';
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{t('aiAssistant')}</h1>
          <p className="text-gray-600">{t('aiAssistantLongDesc')}</p>
        </div>
        
        <Card className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
          <div className="border-b border-gray-200 p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">{t('guidexAssistant')}</h3>
                <p className="text-sm text-green-500">{t('online')}</p>
              </div>
            </div>
          </div>
          
          <div 
            ref={chatMessagesRef}
            className="p-4 h-96 overflow-y-auto custom-scrollbar space-y-4"
          >
            {messages.map((message, index) => (
              <div 
                key={index}
                className={`flex items-start ${message.role === 'user' ? 'justify-end space-x-3' : 'space-x-3'}`}
              >
                {message.role !== 'user' && (
                  <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                    </svg>
                  </div>
                )}
                
                <div 
                  className={`${
                    message.role === 'user' 
                      ? 'bg-primary p-3 rounded-lg chat-bubble-user max-w-xs sm:max-w-md' 
                      : 'bg-gray-100 p-3 rounded-lg chat-bubble-bot max-w-xs sm:max-w-md'
                  }`}
                >
                  {message.isLoading ? (
                    <div className="flex flex-col space-y-2">
                      <div className="flex items-center">
                        <span className="inline-block h-2 w-2 rounded-full bg-indigo-400 mr-1 animate-pulse"></span>
                        <span className="inline-block h-2 w-2 rounded-full bg-indigo-400 mr-1 animate-pulse" style={{ animationDelay: "0.2s" }}></span>
                        <span className="inline-block h-2 w-2 rounded-full bg-indigo-400 animate-pulse" style={{ animationDelay: "0.4s" }}></span>
                      </div>
                      <p className="text-gray-500 text-sm">Generating a helpful response...</p>
                    </div>
                  ) : (
                    <p className={`${message.role === 'user' ? 'text-white' : 'text-gray-700'} ${message.isError ? 'text-red-500' : ''}`}>
                      {message.content}
                    </p>
                  )}
                  <p className={`text-xs ${message.role === 'user' ? 'text-indigo-200' : 'text-gray-500'} mt-1`}>
                    {formatTime(message.timestamp)}
                  </p>
                </div>
                
                {message.role === 'user' && (
                  <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                  </div>
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
          
          <div className="border-t border-gray-200 p-4">
            <form onSubmit={handleSubmit} className="flex items-center space-x-2">
              <Input
                type="text"
                id="messageInput"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={t('typePlaceholder')}
                className="flex-grow rounded-lg border border-gray-200 py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                disabled={isLoading}
              />
              <Button 
                type="submit" 
                className="bg-primary hover:bg-indigo-600 text-white rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition"
                disabled={isLoading}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              </Button>
            </form>
          </div>
        </Card>
        
        <div className="mt-8">
          <h3 className="text-xl font-semibold text-gray-800 mb-4">{t('suggestedQuestions')}</h3>
          <div className="flex flex-wrap gap-2">
            {suggestedQuestions.map((question, index) => (
              <button
                key={index}
                onClick={() => handleSuggestedQuestion(question)}
                className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-full px-4 py-2 text-sm font-medium transition"
              >
                {question}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AiAssistant;
