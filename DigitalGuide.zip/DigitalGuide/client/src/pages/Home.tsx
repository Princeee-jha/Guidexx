import { Link } from "wouter";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

const Home = () => {
  const { t } = useLanguage();

  const features = [
    {
      title: t('aiAssistant'),
      description: t('aiAssistantDesc'),
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
        </svg>
      ),
      color: "indigo",
      link: "/ai-assistant",
      linkText: t('tryNow')
    },
    {
      title: t('communityChat'),
      description: t('communityChatDesc'),
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
        </svg>
      ),
      color: "emerald",
      link: "/community-chat",
      linkText: t('joinChat')
    },
    {
      title: t('contactExperts'),
      description: t('contactExpertsDesc'),
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
        </svg>
      ),
      color: "amber",
      link: "/contact-experts",
      linkText: t('reachOut')
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">{t('welcome')}</h1>
        <p className="text-xl md:text-2xl font-medium text-gray-700 mb-8 leading-relaxed">{t('tagline')}</p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
          <Link href="/ai-assistant">
            <Button 
              className="bg-primary hover:bg-indigo-600 text-white px-6 py-3 rounded-lg font-medium shadow-md transition w-full sm:w-auto hover:scale-105 hover:shadow-lg"
            >
              {t('getStarted')}
            </Button>
          </Link>
          <Button 
            variant="outline" 
            className="bg-white hover:bg-gray-50 text-gray-700 px-6 py-3 rounded-lg font-medium shadow-md border border-gray-200 transition w-full sm:w-auto hover:scale-105"
            onClick={() => {
              // Scroll to "How it Works" section
              const howItWorksSection = document.getElementById('how-it-works');
              if (howItWorksSection) {
                howItWorksSection.scrollIntoView({ behavior: 'smooth' });
              }
            }}
          >
            {t('learnMore')}
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {features.map((feature, index) => (
          <Card 
            key={index} 
            className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden border border-gray-100 hover:translate-y-[-5px]"
          >
            <div className={`bg-${feature.color}-500 h-2`}></div>
            <div className="p-6">
              <div className={`w-12 h-12 bg-${feature.color}-100 rounded-lg text-${feature.color === 'indigo' ? 'primary' : feature.color}-500 flex items-center justify-center mb-4`}>
                {feature.icon}
              </div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">{feature.title}</h3>
              <p className="text-gray-600 mb-4">{feature.description}</p>
              <Link 
                href={feature.link} 
                className={`text-${feature.color === 'indigo' ? 'primary' : feature.color}-500 hover:text-${feature.color === 'indigo' ? 'indigo' : feature.color}-600 font-medium inline-flex items-center transition-all duration-200 hover:translate-x-1`}
              >
                <span>{feature.linkText}</span>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </Link>
            </div>
          </Card>
        ))}
      </div>

      <div id="how-it-works" className="mt-16 max-w-4xl mx-auto">
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">{t('howItWorks')}</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-primary text-xl font-bold">1</span>
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">{t('step1Title')}</h3>
            <p className="text-gray-600">{t('step1Desc')}</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-primary text-xl font-bold">2</span>
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">{t('step2Title')}</h3>
            <p className="text-gray-600">{t('step2Desc')}</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-primary text-xl font-bold">3</span>
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">{t('step3Title')}</h3>
            <p className="text-gray-600">{t('step3Desc')}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
