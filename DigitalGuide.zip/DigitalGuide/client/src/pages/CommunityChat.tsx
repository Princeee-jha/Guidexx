import { useState, useEffect, useRef } from 'react';
import { useLanguage } from "@/contexts/LanguageContext";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface Message {
  id?: number;
  sender: string;
  content: string;
  timestamp: Date;
}

interface User {
  name: string;
  profession: string;
  color: string;
  status: 'online' | 'offline';
}

interface Topic {
  name: string;
  userCount: number;
}

const CommunityChat = () => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [websocket, setWebsocket] = useState<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [username, setUsername] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Sample active users data
  const activeUsers: User[] = [
    { name: 'Sophia Anderson', profession: 'Frontend Developer', color: 'emerald', status: 'online' },
    { name: 'James Wilson', profession: 'UX Designer', color: 'blue', status: 'online' },
    { name: 'Emily Chen', profession: 'Data Scientist', color: 'purple', status: 'online' },
    { name: 'Daniel Kumar', profession: 'Backend Developer', color: 'amber', status: 'online' }
  ];

  // Sample topics data
  const topics: Topic[] = [
    { name: 'Web Development', userCount: 142 },
    { name: 'UI/UX Design', userCount: 98 },
    { name: 'Data Science', userCount: 76 },
    { name: 'Mobile Development', userCount: 64 }
  ];

  useEffect(() => {
    // Generate a random username for demo
    const randomName = `User_${Math.floor(Math.random() * 1000)}`;
    setUsername(randomName);

    // Initialize WebSocket connection
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      setIsConnected(true);
      console.log('WebSocket connected');
    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === 'chat') {
          const newMessage: Message = {
            id: data.id,
            sender: data.sender,
            content: data.message,
            timestamp: new Date(data.timestamp)
          };
          
          setMessages(prev => [...prev, newMessage]);
        } else if (data.type === 'connection') {
          console.log('Connection message:', data.message);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    socket.onclose = () => {
      setIsConnected(false);
      console.log('WebSocket disconnected');
    };

    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
      toast({
        title: 'Connection Error',
        description: 'Failed to connect to chat server',
        variant: 'destructive',
      });
    };

    setWebsocket(socket);

    // Fetch existing messages
    fetchMessages();

    return () => {
      if (socket) {
        socket.close();
      }
    };
  }, []);

  useEffect(() => {
    // Scroll to bottom on new messages
    scrollToBottom();
  }, [messages]);

  const fetchMessages = async () => {
    try {
      const res = await fetch('/api/messages');
      if (!res.ok) {
        throw new Error(`Failed to fetch messages: ${res.status}`);
      }
      const data = await res.json();
      setMessages(data.map((msg: any) => ({
        ...msg,
        timestamp: new Date(msg.createdAt)
      })));
    } catch (error) {
      console.error('Error fetching messages:', error);
      toast({
        title: 'Error',
        description: 'Failed to load chat history',
        variant: 'destructive',
      });
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !isConnected || !websocket) return;

    const message = {
      type: 'chat',
      sender: username,
      message: input
    };

    websocket.send(JSON.stringify(message));
    setInput('');
  };

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{t('communityChat')}</h1>
          <p className="text-gray-600">{t('communityChatLongDesc')}</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Active users sidebar */}
          <div className="lg:col-span-1">
            <Card className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
              <div className="border-b border-gray-200 p-4">
                <h3 className="font-semibold text-gray-800">
                  {t('activeUsers')} ({activeUsers.length})
                </h3>
              </div>
              
              <div className="p-4 h-96 overflow-y-auto custom-scrollbar">
                <div className="space-y-4">
                  {activeUsers.map((user, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <div className="relative">
                        <div className={`w-10 h-10 bg-${user.color}-100 rounded-full flex items-center justify-center`}>
                          <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 text-${user.color}-500`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                          </svg>
                        </div>
                        <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                      </div>
                      <div>
                        <p className="font-medium text-gray-800">{user.name}</p>
                        <p className="text-xs text-gray-500">{user.profession}</p>
                      </div>
                    </div>
                  ))}
                  
                  <div className="pt-2 text-center">
                    <button className="text-sm text-primary hover:text-indigo-600 font-medium">
                      <span>{t('viewAll')}</span>
                    </button>
                  </div>
                </div>
              </div>
            </Card>
            
            <Card className="mt-6 bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
              <div className="border-b border-gray-200 p-4">
                <h3 className="font-semibold text-gray-800">{t('popularTopics')}</h3>
              </div>
              
              <div className="p-4">
                <div className="space-y-2">
                  {topics.map((topic, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-gray-700">{topic.name}</span>
                      <span className="bg-indigo-100 text-indigo-600 text-xs rounded-full px-2 py-1">
                        {topic.userCount} users
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          </div>
          
          {/* Chat area */}
          <div className="lg:col-span-3">
            <Card className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
              <div className="border-b border-gray-200 p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-800">{t('generalChat')}</h3>
                      <p className="text-xs text-gray-500">
                        <span>{t('membersOnline')}</span>: {activeUsers.length}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <button className="text-gray-500 hover:text-gray-700 p-1">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                      </svg>
                    </button>
                    <button className="text-gray-500 hover:text-gray-700 p-1">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h7" />
                      </svg>
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="p-4 h-96 overflow-y-auto custom-scrollbar space-y-4">
                {/* Today date header */}
                <div className="flex justify-center">
                  <div className="bg-gray-100 text-gray-600 text-sm px-4 py-2 rounded-full">
                    {t('todayDate')}
                  </div>
                </div>
                
                {/* Messages */}
                {messages.map((message, index) => (
                  <div 
                    key={index}
                    className={`flex items-start ${message.sender === username ? 'justify-end space-x-3' : 'space-x-3'}`}
                  >
                    {message.sender !== username && (
                      <div className={`w-8 h-8 bg-${getUserColor(message.sender)}-100 rounded-full flex items-center justify-center flex-shrink-0`}>
                        <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 text-${getUserColor(message.sender)}-500`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                      </div>
                    )}
                    
                    {message.sender !== username && (
                      <div>
                        <div className="flex items-center space-x-2 mb-1">
                          <span className="font-medium text-gray-800">{message.sender}</span>
                          <span className="text-xs text-gray-500">{formatTime(message.timestamp)}</span>
                        </div>
                        <div className="bg-gray-100 p-3 rounded-lg chat-bubble-bot max-w-md">
                          <p className="text-gray-700">{message.content}</p>
                        </div>
                      </div>
                    )}
                    
                    {message.sender === username && (
                      <>
                        <div className="bg-primary p-3 rounded-lg chat-bubble-user max-w-md">
                          <p className="text-white">{message.content}</p>
                        </div>
                        <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center flex-shrink-0">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                          </svg>
                        </div>
                      </>
                    )}
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
              
              <div className="border-t border-gray-200 p-4">
                <form onSubmit={handleSubmit} className="flex items-center space-x-2">
                  <button type="button" className="text-gray-500 hover:text-gray-700 p-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                    </svg>
                  </button>
                  <Input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder={t('typePlaceholder')}
                    className="flex-grow rounded-lg border border-gray-200 py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    disabled={!isConnected}
                  />
                  <button type="button" className="text-gray-500 hover:text-gray-700 p-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </button>
                  <Button 
                    type="submit" 
                    className="bg-primary hover:bg-indigo-600 text-white rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition"
                    disabled={!isConnected}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                    </svg>
                  </Button>
                </form>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper to get consistent user color based on username
function getUserColor(username: string): string {
  const colors = ['emerald', 'blue', 'purple', 'amber', 'indigo'];
  const sum = username.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return colors[sum % colors.length];
}

export default CommunityChat;
