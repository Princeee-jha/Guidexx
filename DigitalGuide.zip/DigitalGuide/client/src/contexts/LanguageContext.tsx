import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { translations } from "@/lib/translations";

type LanguageContextType = {
  language: string;
  setLanguage: (lang: string) => void;
  t: (key: string) => string;
  languages: Record<string, { name: string }>;
};

const languages = {
  en: { name: "English" },
  hi: { name: "हिन्दी (Hindi)" },
  bn: { name: "বাংলা (Bengali)" }
};

const LanguageContext = createContext<LanguageContextType>({
  language: "en",
  setLanguage: () => {},
  t: (key: string) => key,
  languages
});

export const useLanguage = () => useContext(LanguageContext);

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguageState] = useState(() => {
    const saved = localStorage.getItem("guidex-language");
    return saved && Object.keys(languages).includes(saved) ? saved : "en";
  });

  useEffect(() => {
    localStorage.setItem("guidex-language", language);
  }, [language]);

  const setLanguage = (lang: string) => {
    if (Object.keys(languages).includes(lang)) {
      setLanguageState(lang);
    }
  };

  const t = (key: string): string => {
    const keys = key.split(".");
    let value: any = translations[language];

    for (const k of keys) {
      if (value && value[k]) {
        value = value[k];
      } else {
        // Fallback to English
        let fallback = translations.en;
        for (const fallbackKey of keys) {
          if (fallback && fallback[fallbackKey]) {
            fallback = fallback[fallbackKey];
          } else {
            return key; // Key not found in English either
          }
        }
        return typeof fallback === "string" ? fallback : key;
      }
    }

    return typeof value === "string" ? value : key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, languages }}>
      {children}
    </LanguageContext.Provider>
  );
};
