import { Link } from "wouter";
import LanguageSelector from "@/components/ui/language-selector";
import { useLanguage } from "@/contexts/LanguageContext";

const Navbar = () => {
  const { t } = useLanguage();

  return (
    <header className="bg-white shadow-sm fixed top-0 left-0 right-0 z-10">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Link href="/" className="text-primary font-bold text-2xl">
            Guidex
          </Link>
          <span className="text-gray-500 text-sm hidden md:inline-block">
            {t('subtitle')}
          </span>
        </div>
        
        <LanguageSelector />
      </div>
    </header>
  );
};

export default Navbar;
