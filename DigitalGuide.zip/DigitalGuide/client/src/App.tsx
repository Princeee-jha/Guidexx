import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import AiAssistant from "@/pages/AiAssistant";
import CommunityChat from "@/pages/CommunityChat";
import ContactExperts from "@/pages/ContactExperts";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import MobileNav from "@/components/layout/MobileNav";
import { useEffect, useState } from "react";
import { randomUUID } from "crypto";

function App() {
  const [userId] = useState(() => {
    // Generate or retrieve userId for AI chat history
    const storedId = localStorage.getItem('guidex-user-id');
    if (storedId) return storedId;
    
    const newId = Math.random().toString(36).substring(2, 15);
    localStorage.setItem('guidex-user-id', newId);
    return newId;
  });

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <TooltipProvider>
        <Toaster />
        
        <Navbar />
        
        <main className="flex-grow pt-16 pb-16 md:pb-0">
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/ai-assistant">
              <AiAssistant userId={userId} />
            </Route>
            <Route path="/community-chat" component={CommunityChat} />
            <Route path="/contact-experts" component={ContactExperts} />
            <Route component={NotFound} />
          </Switch>
        </main>
        
        <Footer />
        <MobileNav />
      </TooltipProvider>
    </div>
  );
}

export default App;
