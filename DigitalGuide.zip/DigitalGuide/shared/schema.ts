import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations will be defined after all tables are declared

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const experts = pgTable("experts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  profession: text("profession").notNull(),
  description: text("description").notNull(),
  specializations: text("specializations").array().notNull(),
  avatarColor: text("avatar_color").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Expert relations will be defined after all tables are declared

export const insertExpertSchema = createInsertSchema(experts).pick({
  name: true,
  profession: true,
  description: true,
  specializations: true, 
  avatarColor: true,
});

export const expertQueries = pgTable("expert_queries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  topic: text("topic").notNull(),
  message: text("message").notNull(),
  contactMethod: text("contact_method").notNull(),
  expertId: integer("expert_id").references(() => experts.id),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const expertQueriesRelations = relations(expertQueries, ({ one }) => ({
  expert: one(experts, {
    fields: [expertQueries.expertId],
    references: [experts.id]
  }),
  user: one(users, {
    fields: [expertQueries.userId],
    references: [users.id]
  })
}));

export const insertExpertQuerySchema = createInsertSchema(expertQueries).pick({
  name: true,
  email: true,
  topic: true,
  message: true,
  contactMethod: true,
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  sender: text("sender").notNull(),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const messagesRelations = relations(messages, ({ one }) => ({
  user: one(users, {
    fields: [messages.userId],
    references: [users.id]
  })
}));

export const insertMessageSchema = createInsertSchema(messages).pick({
  content: true,
  sender: true,
});

export const aiMessages = pgTable("ai_messages", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  role: text("role").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAiMessageSchema = createInsertSchema(aiMessages).pick({
  userId: true,
  role: true,
  content: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Expert = typeof experts.$inferSelect;
export type InsertExpert = z.infer<typeof insertExpertSchema>;
export type ExpertQuery = typeof expertQueries.$inferSelect;
export type InsertExpertQuery = z.infer<typeof insertExpertQuerySchema>;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type AiMessage = typeof aiMessages.$inferSelect;
export type InsertAiMessage = z.infer<typeof insertAiMessageSchema>;

// Now define the user relations after all tables are declared
export const usersRelations = relations(users, ({ many }) => ({
  expertQueries: many(expertQueries),
  messages: many(messages),
  aiMessages: many(aiMessages)
}));

// Now define expert relations after all tables are declared
export const expertsRelations = relations(experts, ({ many }) => ({
  expertQueries: many(expertQueries)
}));
